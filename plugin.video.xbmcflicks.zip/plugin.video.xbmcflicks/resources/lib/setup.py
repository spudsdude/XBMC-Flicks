from setuptools import setup
setup(  name="Netflix",
        version="1.0",
        py_modules = ['Netflix'],
        install_requires=['oauth','simplejson']
        )      

