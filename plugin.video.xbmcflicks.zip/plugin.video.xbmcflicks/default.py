"""
    Plugin for streaming your Netflix Instant Queue
"""

# main imports
import sys
import os
import xbmc
import xbmcgui
import xbmcplugin
import urllib

# plugin constants
__plugin__ = "xbmcflicks"
__author__ = "teamumx"
__url__ = ""
__svn_url__ = ""
__useragent__ = ""
__credits__ = "Team UMX"
__version__ = "1.0.0"
__svn_revision__ = "$Revision$"
__XBMC_Revision__ = "22965"
#__settings__ = xbmcaddon.Addon(id='plugin.video.xbmcflicks')

if ( __name__ == "__main__" ):
        import resources.lib.menu as menu
        menu


